# Nimbus - RPA for Cloud Deployment & Provisioning

### About

This Repo contains scripts for deploying resources in Azure platform. 
